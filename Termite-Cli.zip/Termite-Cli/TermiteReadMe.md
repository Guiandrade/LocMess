Termite instructions (Linux):

1) Unzip Termite.zip.

2) Under the Termite-Cli directory, open the file etc/platform/X/backends.conf, where X is your target platform: windows, linux, or mac.

3) Update sdk and vmi.

4) Update working dir in file etc/platform/{linux,mac,windows}/env_setup.sh

5) source env/platform/{linux,mac,windows}/env_setup.sh

6) rm ~/.emulator_console_auth_token

7) touch ~/.emulator_console_auth_token

8) sh termite.sh

9) load LocMess
