#!/usr/bin/env bash

#
# Absolute path to the Termite CLI tool
#
export TERMITE_CLI_PATH=/Users/nsantos/Documents/bitbucket/project-termite/CMU1516/trunk/TermiteCMov/Termite-Cli

#
# Target platform; one of: mac, linux, or windows
#
export TERMITE_PLATFORM=mac
